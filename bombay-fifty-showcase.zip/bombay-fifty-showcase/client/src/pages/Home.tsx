import { Streamdown } from 'streamdown';
import { ArrowRight, Utensils, Facebook, Instagram, MessageCircle, Phone } from 'lucide-react';
import { useState } from 'react';

const article1 = `# From Bandra to Dubai: The Heartfelt Story Behind Bombay Fifty

In the bustling culinary landscape of Dubai, where flashy dining concepts often overshadow the soul of cooking, **Bombay Fifty** stands out as a beacon of authenticity. Founded by **Chef Hamdan Hurzook**, this "Modern Indian Kitchen" is more than just a restaurant; it is a tribute to a childhood spent between two vibrant cities and a mother's kitchen that defined the meaning of "real food."

## The Meaning of "Fifty"

Many patrons enjoy the aromatic biryanis and succulent kebabs of Bombay Fifty, but few know the secret behind its name. The "Fifty" in Bombay Fifty is a nostalgic nod to **Bandra**, the "Queen of Suburbs" in Mumbai. Specifically, it represents the postal code **400050**, the area where Chef Hamdan's family home is located. It serves as a constant reminder of his roots and the authentic flavors that originated from that specific corner of the world.

## Born in Bombay, Raised in Dubai

Chef Hamdan's journey is a reflection of Dubai's multicultural essence. Growing up in the city in the early 80s, he was surrounded by a melting pot of cultures, yet it was the smell of roasted spices and slow-cooked gravy in his mother's kitchen that stayed with him. He realized that while Dubai had plenty of Indian restaurants, many lacked the "warmth" and "story" of home-cooked meals.

> "Food is more than nourishment—it's a way to bring people together, create lasting memories, and share the joy of life." — Chef Hamdan Hurzook

## A Commitment to Purity

What sets Bombay Fifty apart is its uncompromising stance on health and quality. In an era of fast food and shortcuts, they have made bold choices: only high-quality Sunflower Oil and Pure Ghee are used, never palm oil. There is no MSG or artificial colors, staying true to natural, wholesome flavors. All meats and vegetables are sourced fresh daily, never frozen.

By choosing to remain primarily a **takeaway-only concept**, Bombay Fifty ensures that every batch is cooked with the same care as a family meal, delivering a piece of home across Dubai, one order at a time.`;

const article2 = `# A Symphony of Spices: Exploring the Signature Flavors of Bombay Fifty

When you order from **Bombay Fifty**, you aren't just getting a meal; you are experiencing a "layered symphony" of flavors. The menu is a carefully curated journey through India's diverse culinary landscape, with a specific focus on the bold, vibrant tastes of Bombay.

## The Crown Jewel: Dum Biryani

The undisputed star of the menu is the **Dum Biryani**. Following the traditional "dum" style of slow cooking, the spices and ingredients are allowed to fully infuse, resulting in an aromatic dish where every grain of rice tells a story. The **Mutton Biryani** features tender mutton, marinated overnight and slow-cooked to perfection. The **Chicken Biryani** offers juicy, seasoned chicken that serves as the ultimate comfort food. The **Prawn Biryani** provides a coastal indulgence that balances delicate seafood with aromatic basmati rice.

## Beyond the Biryani: The Grill and Curries

While the biryani might be the first thing people notice, the supporting cast is equally impressive. The **Signature Seekh Paratha** has become a crowd favorite, bringing the authentic taste of Mumbai's street food to the heart of Dubai. Other must-try items include the **Galouti Kebab**, melt-in-the-mouth kebabs that showcase the kitchen's grill mastery, the **Butter Chicken**, a rich, velvety experience with a luscious tomato gravy, and **Aloo Gosht**, a comforting classic that evokes memories of traditional Indian homes.

## The Philosophy of "Mindful Cooking"

At Bombay Fifty, the innovation lies in the respect for tradition. Chef Hamdan doesn't try to "restaurant-ify" the food. Instead, he lets the ingredients speak for themselves. By using **homemade spice blends** and avoiding preservatives, the restaurant offers a "lighter experience" that doesn't leave you feeling heavy, despite the richness of the flavors.

## Perfect for Every Occasion

Whether it's a quiet dinner at home or a large-scale celebration, Bombay Fifty has redefined how Indian food is enjoyed in Dubai. Their **Party Orders** have become a staple for office lunches and family gatherings, proving that great food doesn't need a fancy setting—it just needs heart, soul, and the right blend of spices.`;

export default function Home() {
  const [activeArticle, setActiveArticle] = useState<1 | 2>(1);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F1E8] to-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8E0D0]">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Utensils className="w-6 h-6 text-[#C85A3A]" />
            <h1 className="text-2xl font-bold text-[#2D5016]">Bombay Fifty</h1>
          </div>
          <p className="text-sm text-gray-600 hidden sm:block">A Culinary Journey</p>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-16 sm:py-24 bg-gradient-to-r from-[#2D5016] to-[#3D6B1F] text-white overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h2 className="text-4xl sm:text-5xl font-bold mb-6 leading-tight">From Bandra to Dubai</h2>
            <p className="text-lg sm:text-xl text-gray-100 mb-8 leading-relaxed">Discover the authentic story of Chef Hamdan's journey, the meaning behind the name, and the philosophy that makes Bombay Fifty a beacon of culinary authenticity in Dubai.</p>
            <div className="flex gap-4 flex-wrap">
              <button
                onClick={() => setActiveArticle(1)}
                className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                  activeArticle === 1
                    ? 'bg-[#C85A3A] text-white'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                The Story
              </button>
              <button
                onClick={() => setActiveArticle(2)}
                className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                  activeArticle === 2
                    ? 'bg-[#C85A3A] text-white'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                The Flavors
              </button>
            </div>
          </div>
        </div>
        {/* Decorative element */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#C85A3A]/10 rounded-full blur-3xl"></div>
      </section>

      {/* Articles Section */}
      <section className="py-16 sm:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Article 1 */}
            {activeArticle === 1 && (
              <div className="animate-fade-in">
                <article className="prose prose-lg max-w-none prose-headings:text-[#2D5016] prose-headings:font-bold prose-a:text-[#C85A3A] prose-strong:text-[#2D5016]">
                  <Streamdown>{article1}</Streamdown>
                </article>
              </div>
            )}

            {/* Article 2 */}
            {activeArticle === 2 && (
              <div className="animate-fade-in">
                <article className="prose prose-lg max-w-none prose-headings:text-[#2D5016] prose-headings:font-bold prose-a:text-[#C85A3A] prose-strong:text-[#2D5016]">
                  <Streamdown>{article2}</Streamdown>
                </article>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 sm:py-24 bg-[#F5F1E8]">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-[#2D5016] mb-12">Why Bombay Fifty Stands Out</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-sm border-l-4 border-[#C85A3A]">
              <div className="text-3xl font-bold text-[#C85A3A] mb-2">100%</div>
              <p className="text-gray-700 font-semibold">Fresh Ingredients</p>
              <p className="text-sm text-gray-600 mt-2">Never frozen, sourced daily</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm border-l-4 border-[#C85A3A]">
              <div className="text-3xl font-bold text-[#C85A3A] mb-2">0</div>
              <p className="text-gray-700 font-semibold">Artificial Additives</p>
              <p className="text-sm text-gray-600 mt-2">No MSG, no artificial colors</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm border-l-4 border-[#C85A3A]">
              <div className="text-3xl font-bold text-[#C85A3A] mb-2">Pure</div>
              <p className="text-gray-700 font-semibold">Cooking Oils</p>
              <p className="text-sm text-gray-600 mt-2">Ghee & sunflower oil only</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm border-l-4 border-[#C85A3A]">
              <div className="text-3xl font-bold text-[#C85A3A] mb-2">400050</div>
              <p className="text-gray-700 font-semibold">Bandra Postal Code</p>
              <p className="text-sm text-gray-600 mt-2">The story behind the name</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact & Social Media Section */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl sm:text-4xl font-bold text-center text-[#2D5016] mb-12">رابطہ کریں / Get in Touch</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {/* Phone */}
            <a
              href="tel:+971529795030"
              className="flex flex-col items-center p-8 bg-[#F5F1E8] rounded-lg hover:shadow-lg hover:bg-[#E8E0D0] transition-all"
            >
              <Phone className="w-8 h-8 text-[#C85A3A] mb-4" />
              <p className="font-semibold text-[#2D5016] mb-2">Phone</p>
              <p className="text-sm text-gray-600 text-center">+971 52 979 5030</p>
            </a>

            {/* WhatsApp */}
            <a
              href="https://wa.me/971529795030"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center p-8 bg-[#F5F1E8] rounded-lg hover:shadow-lg hover:bg-[#E8E0D0] transition-all"
            >
              <MessageCircle className="w-8 h-8 text-[#C85A3A] mb-4" />
              <p className="font-semibold text-[#2D5016] mb-2">WhatsApp</p>
              <p className="text-sm text-gray-600 text-center">Chat with us</p>
            </a>

            {/* Facebook */}
            <a
              href="https://www.facebook.com/100091383679332/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center p-8 bg-[#F5F1E8] rounded-lg hover:shadow-lg hover:bg-[#E8E0D0] transition-all"
            >
              <Facebook className="w-8 h-8 text-[#C85A3A] mb-4" />
              <p className="font-semibold text-[#2D5016] mb-2">Facebook</p>
              <p className="text-sm text-gray-600 text-center">Follow us</p>
            </a>

            {/* Instagram */}
            <a
              href="https://www.instagram.com/bombayfifty/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center p-8 bg-[#F5F1E8] rounded-lg hover:shadow-lg hover:bg-[#E8E0D0] transition-all"
            >
              <Instagram className="w-8 h-8 text-[#C85A3A] mb-4" />
              <p className="font-semibold text-[#2D5016] mb-2">Instagram</p>
              <p className="text-sm text-gray-600 text-center">@bombayfifty</p>
            </a>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-r from-[#2D5016] to-[#3D6B1F] text-white">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl sm:text-4xl font-bold mb-6">Experience Authentic Bombay Flavors</h3>
          <p className="text-lg text-gray-100 mb-8 max-w-2xl mx-auto">Order from Bombay Fifty and bring the warmth of Chef Hamdan's kitchen to your home.</p>
          <a
            href="https://bombayfifty.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#C85A3A] hover:bg-[#B84A2A] text-white px-8 py-4 rounded-lg font-semibold transition-all"
          >
            Visit Bombay Fifty <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2D5016] text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-300">© 2026 Bombay Fifty. All Rights Reserved.</p>
          <p className="text-sm text-gray-400 mt-2">A culinary journey from Bandra to Dubai</p>
        </div>
      </footer>
    </div>
  );
}
